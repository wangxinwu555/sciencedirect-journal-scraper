ScienceDirect captured article DOM fragments.
Match raw/PII.html SHA-256 to source_sha256 in articles.json.
Original titles and abstracts retain their original authors, publishers and licensing terms.
No browser profiles, credentials or diagnostic screenshots are included.
